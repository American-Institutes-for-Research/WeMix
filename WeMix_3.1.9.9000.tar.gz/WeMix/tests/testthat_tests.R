library(testthat)
library(WeMix)
Sys.setenv(NOT_CRAN="")
test_check('WeMix')
