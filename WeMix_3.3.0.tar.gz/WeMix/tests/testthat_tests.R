library(testthat)
library(WeMix)
test_check('WeMix')
