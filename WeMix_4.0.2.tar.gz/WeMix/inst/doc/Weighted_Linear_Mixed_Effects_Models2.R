## ----code options, echo = FALSE----------------------------------------------------
options(width = 85)

## ----load package, results="hide", message=FALSE-----------------------------------
library(EdSurvey)
library(WeMix)
require(tidyr)
# download ECLS:K 2011 data; run once, then unzip
# downloadECLS_K(root="~/", years=2011)
# read data in with EdSurvey
ecls <- readECLS_K2011("~/OneDrive - AIR/Documents/ECLS_K/2011/")

## ----getData, results="hide", message=FALSE----------------------------------------
# extract relevant columns in wide format (one row per person)
ecls_wide <- EdSurvey::getData(ecls,
                               c("childid", "x1mscalk5", "x2mscalk5",
                                 "x3mscalk5","x4mscalk5", "x5mscalk5", 
                                 "x6mscalk5", "x7mscalk5", "x8mscalk5",
                                 "x9mscalk5", "w9c19p_90","s2_id","w2sch0"))
# filter to those with positive weight (have relevant data)
ecls_wide <- subset(ecls_wide, w9c19p_90 > 0 & w2sch0 > 0)

## ----subset, results="hide", message=FALSE-----------------------------------------
# add students per school, s2_id is the school ID
ecls_wide$nsch <- ave(rep(1, nrow(ecls_wide)), ecls_wide$s2_id, FUN=length)
ecls_wide <- subset(ecls_wide, nsch >= 10)

## ----wide2long, results="hide", message=FALSE--------------------------------------
# wide to long
ecls_long <- gather(data=ecls_wide, key="scorevar", value="score",
                    c("x1mscalk5", "x2mscalk5", "x3mscalk5", 
                      "x4mscalk5", "x5mscalk5", "x6mscalk5", 
                      "x7mscalk5", "x8mscalk5", "x9mscalk5") )

## ----wave, results="hide", message=FALSE-------------------------------------------
# add wave calendar years since start of the study
ecls_long$wave <- substr(ecls_long$scorevar, 2, 2)
ecls_long$calYear <- ifelse(ecls_long$wave==1, 0, NA) # fall 2010 (October)
ecls_long$calYear <- ifelse(ecls_long$wave==2, 6/12, ecls_long$calYear) # Spring 2011 (April)
ecls_long$calYear <- ifelse(ecls_long$wave==3, 12/12, ecls_long$calYear) # Fall 2011 
ecls_long$calYear <- ifelse(ecls_long$wave==4, 18/12, ecls_long$calYear) # Spring 2012
ecls_long$calYear <- ifelse(ecls_long$wave==5, 24/12, ecls_long$calYear) # Fall 2012
ecls_long$calYear <- ifelse(ecls_long$wave==6, 30/12, ecls_long$calYear) # Spring 2013
ecls_long$calYear <- ifelse(ecls_long$wave==7, 42/12, ecls_long$calYear) # Spring 2014
ecls_long$calYear <- ifelse(ecls_long$wave==8, 54/12, ecls_long$calYear) # Spring 2015
ecls_long$calYear <- ifelse(ecls_long$wave==9, 66/12, ecls_long$calYear) # Spring 2016

## ----weight1, results="hide", message=FALSE----------------------------------------
# add weights
ecls_long$w3 <- ecls_long$w2sch0 # school selection prob
ecls_long$w2 <- ecls_long$w9c19p_90 # student unconditional weight
ecls_long$w1c <- 1 # test conditional prob, always 1
ecls_long$w1 <- ecls_long$w1c * ecls_long$w2 # final score-level weight

## ----reweight, results="hide", message=FALSE---------------------------------------
# re-weight so total school weight is n-schools 
unique_schools <- ecls_long[!duplicated(ecls_long$s2_id), ]
ecls_long$w3 <- nrow(unique_schools)/ sum(unique_schools$w3) * ecls_long$w3
# re-weight so total student weight is n-students
unique_stu <- ecls_long[!duplicated(ecls_long$childid), ]
ecls_long$w2 <- nrow(unique_stu) / sum(unique_stu$w2) * ecls_long$w2
# remain self-representing
ecls_long$w1 <- ecls_long$w2

